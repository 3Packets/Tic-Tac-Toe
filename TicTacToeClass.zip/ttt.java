package tic_tac_toe;

public interface ttt {

	static void displayBoard() {
		// TODO Auto-generated method stub
		
	}

}
